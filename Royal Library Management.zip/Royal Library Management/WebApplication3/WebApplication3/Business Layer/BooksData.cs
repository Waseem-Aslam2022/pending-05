﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using RoyalLibrary.Data_Layer;

namespace RoyalLibrary.Business_Layer
{
    public class BooksData : IBooksData
    {
        IBookData _bookData;

        public BooksData(IBookData bookData)
        {
            this._bookData = bookData;
        }
        //get all books
        public List<Books> GetAllBooks()
        {
            return this._bookData.GetAllBooks();
        }
        //get books data by book name
        public Books GetBookData(string bookName)
        {
            return this._bookData.GetBookData(bookName);
        }
        //add new book
        public string AddNewBook(Books newBook)
        {
            return this._bookData.AddNewBook(newBook);
        }
        //update Book Reccord
        public string UpdateBookRecord(int id,Books book)
        {
            return this._bookData.UpdateBookRecord(id,book);
        }
        //delete book
        public string DeleteBook(int bookId)
        {
            return this._bookData.DeleteBook(bookId);
        }
        //return book
        public string ReturnBook(int bookId)
        {
            return this._bookData.ReturnBook(bookId);
        }
        //isssue a new book
        public string IssueNewBook(int userId, int bookId)
        {
            return this._bookData.IssueNewBook(userId,bookId);
        }
    }
}
