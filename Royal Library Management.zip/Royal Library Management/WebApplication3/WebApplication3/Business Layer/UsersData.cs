﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using RoyalLibrary.Data_Layer;

namespace RoyalLibrary.Business_Layer
{
    public class UsersData : IUsersData
    {
        IUserData _userData;
        //Extract Users Data
        public UsersData(IUserData userData)
        {
            this._userData = userData;
        }
        //get all users
        public List<Users> GetAllUsers()
        {
            return this._userData.GetAllUsers();
        }
        //get user data
        public Users GetUserData(int userId)
        {
            return this._userData.GetUserData(userId);
        }
        //add new user
        public string AddNewUser(Users newUser)
        {
            return this._userData.AddNewUser(newUser);
        }
        //update user record
        public string UpdateUserRecord(int id,Users user)
        {
            return this._userData.UpdateUserRecord(id,user);
        }
        //delete user
        public string DeleteUser(int userId)
        {
            return this._userData.DeleteUser(userId);
        }
        //Calculate Fine
        public string CalculateFine(int userId)
        {

            int payableFine = 0;
            //fine per day Rs 1
            int perDayFine = 1;
             List<DateTime> holidays = new List<DateTime>()
            { Convert.ToDateTime("2022/10/01"), Convert.ToDateTime("2022/12/01") };
             List<string> Weekend = new List<string> { "Sunday", "Saturday" };
             List<DateTime> dates = this._userData.FineCalculationDates(userId);

            int workingDays = WorkingDays(dates[0], dates[1], holidays, Weekend);
            if (workingDays > 15)
            {
                //calculate fine
                payableFine = (workingDays - 15) * perDayFine;
            }
            else
            {
                //Exception Handling
                //if working days less than 15
                return "Thanks For Returning Book--";
            }
            //if working days greater than 15
            return "Sorry Dear! Your Membership Has Been Cancelled. You Have To Pay Fine: Rs." + payableFine;
        }
        public int WorkingDays(DateTime issueDate, DateTime returnDate,
            List<DateTime> holidays,
            List<string> weekend)
        {
            int count = 0;
            for (DateTime currentDate = issueDate; currentDate <= returnDate; 
                currentDate = currentDate.AddDays(1))
            {
                 string currentDay = (currentDate.DayOfWeek).ToString();

                if (!(weekend.Contains(currentDay) || holidays.Contains(currentDate)))
                {
                    count++;
                }
            }
            return count;
        }

        public Users GetUserData(string userName)
        {
            throw new NotImplementedException();
        }
    }
}
