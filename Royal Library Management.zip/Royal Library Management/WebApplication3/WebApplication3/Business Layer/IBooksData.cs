﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RoyalLibrary.Business_Layer
{
    public interface IBooksData
    {
        public List<Books> GetAllBooks();
        public Books GetBookData(string bookName);
        public string AddNewBook(Books newBook);
        public string UpdateBookRecord(int id,Books book);
        public string DeleteBook(int bookId);
        public string ReturnBook(int bookId);
        public string IssueNewBook(int userId, int bookId);
    }
}
