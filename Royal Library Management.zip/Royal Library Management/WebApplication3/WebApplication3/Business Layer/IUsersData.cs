﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RoyalLibrary.Business_Layer
{
    //Using Interface
    public interface IUsersData
    {
        public List<Users> GetAllUsers();
        public Users GetUserData(int userId);
        public string AddNewUser(Users newUser);
        public string UpdateUserRecord(int id,Users user);
        public string DeleteUser(int userId);
        public string CalculateFine(int userId);
        public int WorkingDays(DateTime issueDate, DateTime returnDate, List<DateTime> holidays,
            List<string> weekend);
        Users GetUserData(string userName);

    }
}
