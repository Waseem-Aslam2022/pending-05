﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using RoyalLibrary.Business_Layer;

namespace RoyalLibrary.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class RoyalLibraryController : ControllerBase
    {
        IBooksData _booksdata;
        IUsersData _usersdata;
        public RoyalLibraryController(IBooksData booksData,IUsersData usersData)
        {
            _booksdata = booksData;
            _usersdata = usersData;
        }
        [Route("getallbooks")]
        [HttpGet]
        public IEnumerable<Books> GetAllBooks()
        {
            return _booksdata.GetAllBooks();
        }
        [Route("getbookdata/{bookName}")]
        [HttpGet]
        public Books GetBookData(string bookName)
        {
            return _booksdata.GetBookData(bookName);
        }
        [Route("getallusers")]
        [HttpGet]
        public IEnumerable<Users> GetAllUsers()
        {
            return _usersdata.GetAllUsers();
        }
        [Route("getuserdata/{userId}")]
        [HttpGet]
        public Users GetUserData(int userId)
        {
            return _usersdata.GetUserData(userId);
        }
        [Route("addnewbook")]
        [HttpPost]
        public string AddNewBook([FromBody] Books newBook)
        {
            return _booksdata.AddNewBook(newBook);
        }
        [Route("addnewuser")]
        [HttpPost]
        public string AddNewUser([FromBody] Users newUser)
        {
            return _usersdata.AddNewUser(newUser);
        }
        [Route("updatebook/{id}")]
        [HttpPut]
        public string UpdateBookRecord(int id,[FromBody] Books book)
        {
            return _booksdata.UpdateBookRecord(id,book);
        }
        [Route("updateuser/{id}")]
        [HttpPut]
        public string UpdateUserRecord(int id,[FromBody] Users user)
        {
            return _usersdata.UpdateUserRecord(id,user);
        }
        [Route("deletebook/{bookId}")]
        [HttpDelete]
        public string DeleteBook(int bookId)
        {
            return _booksdata.DeleteBook(bookId);
        }
        [Route("deleteuser/{userId}")]
        [HttpDelete]
        public string DeleteUser(int userId)
        {
            return _usersdata.DeleteUser(userId);
        }
        [Route("returnbook/{bookId}")]
        [HttpPut]
        public string ReturnBook(int bookId)
        {
            return _booksdata.ReturnBook(bookId);
        }
        [Route("issuenewbook/{userId}/{bookId}")]
        [HttpPut]
        public string IssueNewBook(int userId,int bookId)
        {
            return _booksdata.IssueNewBook(userId,bookId);
        }
        [Route("calculatefine/{userId}")]
        [HttpGet]
        public string CalculateFine(int userId)
        {
            return _usersdata.CalculateFine(userId);
        }
    }
}
