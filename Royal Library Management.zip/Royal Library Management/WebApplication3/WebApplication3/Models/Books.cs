using System;

namespace RoyalLibrary
{
    public class Books
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Catagory { get; set; }
        public int ShelfNumber { get; set; }
        public int Price { get; set; }
        public string status { get; set; }
    }
}
