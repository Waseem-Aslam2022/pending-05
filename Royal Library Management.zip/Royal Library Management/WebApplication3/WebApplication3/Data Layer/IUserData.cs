﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RoyalLibrary.Data_Layer
{
    public interface IUserData
    {
        public List<Users> GetAllUsers();
        public Users GetUserData(int userId);
        public string AddNewUser(Users user);
        public string UpdateUserRecord(int id,Users user);
        public string DeleteUser(int userId);
        public List<DateTime> FineCalculationDates(int userId);
    }
}
