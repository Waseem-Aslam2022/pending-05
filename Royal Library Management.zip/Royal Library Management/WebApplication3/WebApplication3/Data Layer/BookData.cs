﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using Microsoft.Extensions.Configuration;


namespace RoyalLibrary.Data_Layer
{
    public class BookData : IBookData
    {
        string connectionString = "";
        //Get Connect with database
        public BookData(IConfiguration config)
        {
            var myVar = config;
            //connecting String
            connectionString = config.GetConnectionString("ProjectDB");
        }
        //Get All Books 
        public List<Books> GetAllBooks()
        {
            List<Books> bookList = new List<Books>();

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                //SQL StoredProcedure
                SqlCommand cmd = new SqlCommand("GetBooks", con);
                cmd.CommandType = CommandType.StoredProcedure;

                con.Open();
                SqlDataReader sqlDataReader = cmd.ExecuteReader();

                while (sqlDataReader.Read())
                {
                    Books booksData = new Books();

                    booksData.Id = Convert.ToInt32(sqlDataReader["book_id"]);
                    booksData.Name = sqlDataReader["book_name"].ToString();
                    booksData.Catagory = sqlDataReader["catagory"].ToString();
                    booksData.ShelfNumber = Convert.ToInt32( sqlDataReader["shelf_number"]);
                    booksData.Price = Convert.ToInt32( sqlDataReader["price"]);
                    booksData.status = sqlDataReader["book_status"].ToString();

                    bookList.Add(booksData);
                }
                con.Close();
            }
            return bookList;
        }
        //           <==========================================================>
        //            ************************* Task03 *************************
        //           <==========================================================>

        //get newBook data by name
        public Books GetBookData(string bookName)
        {
            Books book = new Books();

            using (SqlConnection myConnection = new SqlConnection(connectionString))
            {
                //Call sql Stored Procedure
                using (SqlCommand cmd = new SqlCommand("BookData", myConnection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    myConnection.Open();
                    //Stored procedure parameter values
                    SqlParameter name = cmd.Parameters.AddWithValue("@name", bookName);

                    using (SqlDataReader sqlDataReader = cmd.ExecuteReader())
                    {
                        //Read Data From Stored Procedure 
                        if (sqlDataReader.Read())
                        {
                            book.Id = Convert.ToInt32(sqlDataReader["book_id"]);
                            book.Name = sqlDataReader["book_name"].ToString();
                            book.Catagory = sqlDataReader["catagory"].ToString();
                            book.ShelfNumber = Convert.ToInt32(sqlDataReader["shelf_number"]);
                            book.Price = Convert.ToInt32(sqlDataReader["price"]);
                            book.status = sqlDataReader["book_status"].ToString();
                        }
                    }
                }
            }
            return book; 
        }

        //           <==========================================================>
        //            ************************* Task01 *************************
        //           <==========================================================>

         //Add New Book To the Book List
        public string AddNewBook(Books newBook)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                //Call Stored Procedure
                SqlCommand cmd = new SqlCommand("AddNewBook", con);
                cmd.CommandType = CommandType.StoredProcedure;

                con.Open();
                //Stored Procedure Parameters Values
                cmd.Parameters.AddWithValue("@name", newBook.Name);
                cmd.Parameters.AddWithValue("@catagory", newBook.Catagory);
                cmd.Parameters.AddWithValue("@shelfnumber", newBook.ShelfNumber);
                cmd.Parameters.AddWithValue("@price", newBook.Price);
                cmd.Parameters.AddWithValue("@status", newBook.status);
                //Execute Store Procedure
                cmd.ExecuteNonQuery(); 
                con.Close();

            }
            return "Book is Added To The Library Successfully";
        }

        //           <==========================================================>
        //            ************************* Task05 *************************
        //           <==========================================================>

        //Update Book Record
        public string UpdateBookRecord(int id,Books book)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                //Call Stored Procedure
                SqlCommand cmd = new SqlCommand("UpdateBookRecord", con);
                cmd.CommandType = CommandType.StoredProcedure;

                con.Open();
                //Stored Procedure Parameters Values
                cmd.Parameters.AddWithValue("@id", id);
                cmd.Parameters.AddWithValue("@name", book.Name);
                cmd.Parameters.AddWithValue("@catagory", book.Catagory);
                cmd.Parameters.AddWithValue("@shelfnumber", book.ShelfNumber);
                cmd.Parameters.AddWithValue("@price", book.Price);
                cmd.Parameters.AddWithValue("@status", book.status);
                //Execute Stored Procedure
                cmd.ExecuteNonQuery(); 
                con.Close();

            }
            return "The Book Record Has Been Updated";
        }


        //           <==========================================================>
        //            ************************* Task08 *************************
        //           <==========================================================>

        //Delete Book from newBook list
        public string DeleteBook(int bookId)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                //Call Stored Procedure
                SqlCommand cmd = new SqlCommand("DeleteBook", con);
                cmd.CommandType = CommandType.StoredProcedure;
                
                con.Open();
                //Setting Parameter Value 
                cmd.Parameters.AddWithValue("@id", bookId);

                cmd.ExecuteNonQuery();
                con.Close();

            }
            return "The Book Has Deleted From Book List";
        }

        //           <==========================================================>
        //            ************************* Task10 *************************
        //           <==========================================================>

        public string ReturnBook(int bookId)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                //Call Stored Procedure
                SqlCommand cmd = new SqlCommand("ReturnBook", con);
                cmd.CommandType = CommandType.StoredProcedure;

                con.Open();
                //Setting parameter value 
                cmd.Parameters.AddWithValue("@id", bookId);
                cmd.ExecuteNonQuery(); 
                con.Close();

            }
            return "The Book Has Returned To Book List";
        }

         //           <==========================================================>
        //            ************************* Task07 *************************
        //           <==========================================================>


         public string IssueNewBook(int userId,int bookId)
        {
            int check;
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                //Call Stored Procedure
                SqlCommand cmd = new SqlCommand("IssueNewBook", con);
                cmd.CommandType = CommandType.StoredProcedure;

                con.Open();
                //Setting Parameter value 
                cmd.Parameters.AddWithValue("@userId", userId);
                cmd.Parameters.AddWithValue("@bookId", bookId);
                //Executing Stored procedure and assingn Book To User
                check = Convert.ToInt32(cmd.ExecuteScalar()); 
                con.Close();

            }
            //check if newBook is already issued 
            if (check != -1)
            {
               return "The Book is issued To The User";
            }
            else
            {
                return "This Book Is Issued By Another User";
            }
            
        }
    }
}
