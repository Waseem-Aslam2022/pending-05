﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace RoyalLibrary.Data_Layer
{
    public class UserData : IUserData
    {
        string connectionString = "";
        //Lets Connect With database
        public UserData(IConfiguration config)
        {
            var myVar = config;
            connectionString = config.GetConnectionString("ProjectDB");
        }
        //Get All Users
        public List<Users> GetAllUsers()
        {
            List<Users> userList = new List<Users>();

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                //Call Stored Procedure
                SqlCommand cmd = new SqlCommand("GetUsers", con);
                cmd.CommandType = CommandType.StoredProcedure;

                con.Open();
                SqlDataReader sqlDataReader = cmd.ExecuteReader();

                while (sqlDataReader.Read())
                {
                    Users user = new Users();

                    user.Id = Convert.ToInt32(sqlDataReader["user_id"]);
                    user.Name = sqlDataReader["user_name"].ToString();

                    userList.Add(user);
                }
                con.Close();
            }
            return userList;
        }

        //           <==========================================================>
        //            ************************* Task04 *************************
        //           <==========================================================>

        public Users GetUserData(int userId)
        {
            Users userDetails = new Users();
            userDetails.BookIssuedList = new List<string>();
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                //Call Store procedure 
                string sqlQuery = "UserData";
                SqlDataAdapter SDA = new SqlDataAdapter(sqlQuery, con);
                SDA.SelectCommand.CommandType = CommandType.StoredProcedure;
                con.Open();
                //Setting Parametr Values
                SDA.SelectCommand.Parameters.AddWithValue("@id", userId);
                SDA.SelectCommand.ExecuteNonQuery();
                DataTable dataTable = new DataTable();
                SDA.Fill(dataTable);
                if (dataTable.Columns.Count == 4)
                {
                    userDetails.Id = Convert.ToInt32(dataTable.Rows[0]["user_id"]);
                    userDetails.Name = dataTable.Rows[0]["user_name"].ToString();
                    for (int i = 0; i < dataTable.Rows.Count; i++)
                    {
                        userDetails.BookIssuedList.Add(dataTable.Rows[i]["book_name"].ToString());
                    }
                }
                else
                {
                    userDetails.Id = Convert.ToInt32(dataTable.Rows[0]["user_id"]);
                    userDetails.Name = dataTable.Rows[0]["user_name"].ToString();
                }
                
            }
            return userDetails;
        }

        //           <==========================================================>
        //            ************************* Task02 *************************
        //           <==========================================================>

        //Add New User
         public string AddNewUser(Users newUser)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                //Call Stored Procedure
                SqlCommand cmd = new SqlCommand("AddNewUser", con);
                cmd.CommandType = CommandType.StoredProcedure;

                con.Open();
                //Setting Parameter Value
                cmd.Parameters.AddWithValue("@Name", newUser.Name);
                //Execute Stored Procedure
                cmd.ExecuteNonQuery();  
                con.Close();

            }
            return "The User Has Been Added To The User List";
        }

        //           <==========================================================>
        //            ************************* Task06 *************************
        //           <==========================================================>

         public string UpdateUserRecord(int id,Users user)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                //Call The Stored Procedure
                SqlCommand cmd = new SqlCommand("UpdateUserRecord", con);
                cmd.CommandType = CommandType.StoredProcedure;

                con.Open();
                //Setting Parameter Values
                cmd.Parameters.AddWithValue("@id", id);
                cmd.Parameters.AddWithValue("@Name", user.Name);
                //Execute Stored Procedure
                cmd.ExecuteNonQuery();   
                con.Close();

            }
            return "The User Record Has Been Updated";
        }

        //           <==========================================================>
        //            ************************* Task09 *************************
        //           <==========================================================>
        public string DeleteUser(int userId)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    //Call Stored Procedure
                    SqlCommand cmd = new SqlCommand("DeleteUser", con);
                    cmd.CommandType = CommandType.StoredProcedure;

                    con.Open();
                    //Setting Parameter Values
                    cmd.Parameters.AddWithValue("@id", userId);
                    //executing stored procedure
                    cmd.ExecuteNonQuery();   
                    con.Close();

                }
                return "The User Has Deleted From UserList";
            }
            catch (Exception)
            {
                return "Cannot Delted. The User Has Some Books To Return";
            }

        }

        //           <==========================================================>
        //            ************************* Task 11 *************************
        //           <==========================================================>

        public List<DateTime> FineCalculationDates(int userId)
        {
            List<DateTime> bookDates = new List<DateTime>();

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                //Call Store Procedure
                SqlCommand cmd = new SqlCommand("FineCalculation", con);
                cmd.CommandType = CommandType.StoredProcedure;
                //Setting Parameter value
                cmd.Parameters.AddWithValue("@userId", userId);

                con.Open();
                //Read Data From Sql File
                SqlDataReader sqlDataReader = cmd.ExecuteReader();

                while (sqlDataReader.Read())
                {
                    bookDates.Add((DateTime)sqlDataReader["issueDate"]);
                    bookDates.Add((DateTime)sqlDataReader["returnDate"]);
                }
                con.Close();
            }
            return bookDates;
        }
    }  
}
