
--Get All Books Data 

CREATE PROCEDURE GetBooks
 AS
BEGIN
	SET NOCOUNT ON;

	SELECT * FROM Book_List;
END
GO

--Get All Books Data 

CREATE PROCEDURE GetUsers
 AS
BEGIN
	SET NOCOUNT ON;

	SELECT * FROM User_List;
END
GO

--              <======================================>
--               ************** Task01 ****************
--              <======================================>

--AddNewbook Procedure
CREATE PROCEDURE AddNewBook 
  
	@name varchar(100),
	@catagory varchar(100),
	@shelfnumber int,
	@price int,
	@status varchar(100)
 
AS
BEGIN
	SET NOCOUNT ON;
	--Insert data of book in book table
	INSERT INTO Book_List
	values
	(@name,@catagory,@shelfnumber,@price,@status);
END
GO

--              <======================================>
--               ************** Task02 ****************
--              <======================================>
--AddNewUser

CREATE PROCEDURE AddNewUser
  
	@name varchar(100)
AS
BEGIN
	SET NOCOUNT ON;
	--insert data in users table
	INSERT INTO User_List
	values
	(@name);
END
GO

--              <======================================>
--               ************** Task03 ****************
--              <======================================>

CREATE PROCEDURE BookData 
  
	@name varchar(100)
AS
BEGIN
	SET NOCOUNT ON;
	--get book by name and its details
	SELECT * FROM Book_List
	where book_name=@name

END
GO

--              <======================================>
--               ************** Task04 ****************
--              <======================================>

CREATE PROCEDURE UserData 
  
	@id int
AS
BEGIN
	SET NOCOUNT ON;
	
	IF(Exists(select issuedTo_userId from Issued_Books where issuedTo_userId=@id))
		select user_id,issued_bookId,user_name,book_name 
		from Issued_Books,User_List,Book_List 
		where Issued_Books.issuedTo_userId= @id and User_List.user_id=@id and Book_List.book_id=issued_bookId
	ELSE
		select * from User_List where user_id=@id
END
GO
--              <======================================>
--               ************** Task05 ****************
--              <======================================>

CREATE PROCEDURE UpdateBookRecord 
  
	@id int,
	@name varchar(100),
	@catagory varchar(100),
	@status varchar(100),
	@shelfnumber int,
	@price int
AS
BEGIN
	SET NOCOUNT ON;
	--Update  book detail in books table
	update Book_List
	SET book_name=@name,catagory=@catagory,shelf_number=@shelfnumber,price=@price,book_status=@status
	WHERE book_id=@id
END
GO

--              <======================================>
--               ************** Task06 ****************
--              <======================================>

CREATE PROCEDURE UpdateUserRecord 
  
	@id int,
	@name varchar(100)
AS
BEGIN
	SET NOCOUNT ON;
	--update user record 
 	update User_List
	SET user_name=@name
	WHERE user_id=@id
END
GO

--              <======================================>
--               ************** Task07 ****************
--              <======================================>

CREATE PROCEDURE IssueNewBook 
  
	@userId	int,
	@bookId int
AS
BEGIN	
	--check if book is already issued
	IF(EXISTS(SELECT issued_bookId FROM Issued_Books WHERE issued_bookId=@bookId))
		SELECT -1
	ELSE
		insert into Issued_Books(issued_bookId,issuedTo_userId,issue_date)
		values
		(@bookId,@userId,Getdate())
		--update book status
		update Book_List SET book_status='Issued' WHERE book_id=@bookId 
		
END
GO

--              <======================================>
--               ************** Task08 ****************
--              <======================================>

CREATE PROCEDURE DeleteBook 
  
	@id	int
AS
BEGIN
	SET NOCOUNT ON;
	--delete book record 
	DELETE Issued_Books FROM Book_List
	inner join Issued_Books on Book_List.book_id=Issued_Books.issued_bookId
	WHERE Book_List.book_id=@id
	DELETE FROM Book_List WHERE book_id=@id
END
GO

--              <======================================>
--               ************** Task09 ****************
--              <======================================>
drop procedure DeleteUser;
CREATE PROCEDURE DeleteUser 
 	@id	int
AS
BEGIN
	SET NOCOUNT ON;
	--deleting user data 
	delete from Fine_Calculation where userId=@id
	delete from User_List where user_id=@id
END
GO

exec DeleteUser @id=1;

--              <======================================>
--               ************** Task10 ****************
--              <======================================>
drop procedure ReturnBook
CREATE PROCEDURE ReturnBook 
  
	@id	int
AS
BEGIN
	SET NOCOUNT ON;
	--delete returned book from book issued list and update its status
	delete from Issued_Books where issued_bookId=@id
	update Book_List set book_status='Un_Issued'
	where book_id=@id;
	update Fine_Calculation set returnDate=GETDATE()
	where bookId=@id;
END
GO

--              <======================================>
--               ************** Task11 ****************
--              <======================================>

CREATE PROCEDURE FineCalculation 
    
	@userId	int
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT issueDate,returnDate FROM Fine_Calculation
	WHERE userId=@userId
END
GO