
--Insert into Book List table
insert into Book_List(book_name,catagory,shelf_number,price,book_status)
values
('Egghead by Bo Burnham','Comedy' ,10,100,'Issued'),
('Rosemarys Baby','Horror',20,200,'Un_Issued'),
('Game of Thrones','Fantacy',30,400,'Issued'),
('1st Samuel. Story of Saul','History',40,500,'Un_Issued'),
('THE ZERO SUGAR DIET','Health',50,600,'Issued'),
('Catch-22 by Joseph Heller','Comedy',10,300,'Un_Issued'),
('Hell House','Horror',20,200,'Issued'),
('The Name of the Wind','Fantacy',30,100,'Un_Issued'),
('2nd Kings. Exile','History',40,700,'Issued'),
('THE WHOLE30 COOKBOOK','Health',50,500,'Un_Issued'),
('Cruel Shoes by Steve Martin','Comedy',10,400,'Issued'),
('The Ruins by Scott Smith','Horror',20,300,'Un_Issued'),
('The Way of Kings','Fantacy',30,100,'Issued'),
('1st Kings. Story of Solomon','History',40,700,'Un_Issued'),
('THE LOSE YOUR BELLY DIET','Health',50,400,'Issued'),
('Bossypants by Tina Fey','Comedy',10,200,'Un_Issued'),
('The Exorcist','Horror',20,500,'Issued'),
('Kushiels Dart','Fantacy',30,200,'Un_Issued'),
('Joshua. Conquer','History',40,100,'Un_Issued'),
('The Sellout by Paul Beatty','Comedy',10,600,'Un_Issued');	
	 
select * from Book_List;
 
--Insert into UserList Table
insert into User_List(user_name)
values
	('Waseem'),
	('Zeeshan'),
	('kamran'),
	('Fareed'),
	('Khaqan'),
	('Aslam'),
	('Mustafa'),
	('Sami'),
	('Haseeb'),
	('Nouman');

select * from User_List;

--Insert data in Issued Books table
insert into Issued_Books(issuedTo_userId,issued_bookId,issue_date)
values
	(1,1,'2022-10-01'),
	(2,3,'2022-10-07'),
	(3,5,'2022-10-12'),
	(4,7,'2022-10-15'),
	(5,9,'2022-10-18'),
	(6,11,'2022-10-20'),
	(7,13,'2022-10-22'),
	(8,15,'2022-10-24'),
	(9,17,'2022-10-27'),
	(10,19,'2022-10-30');

select * from Issued_Books;

--Insert into Fine Calculation Table
insert into Fine_Calculation(userId,bookId,issueDate)
values
   (1,1,'2022-10-01'),
	(2,3,'2022-10-07'),
	(3,5,'2022-10-12'),
	(4,7,'2022-10-15'),
	(5,9,'2022-10-18'),
	(6,11,'2022-10-20'),
	(7,13,'2022-10-22'),
	(8,15,'2022-10-24'),
	(9,17,'2022-10-27'),
	(10,19,'2022-10-30');

	select * from Fine_Calculation;