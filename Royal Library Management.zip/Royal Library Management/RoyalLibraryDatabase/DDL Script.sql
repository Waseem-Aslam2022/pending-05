--Create Table for Book List
Create Table Book_List(
book_id int not null PRIMARY KEY IDENTITY(1,1),
book_name VARCHAR(100),
catagory VARCHAR(100),
shelf_number INT,
price INT,
book_status VARCHAR(100),

)
SELECT * FROM Book_List;

--Create table for User List
CREATE TABLE User_List(
user_id INT PRIMARY key identity(1,1),
user_name VARCHAR(100)
)
SELECT * FROM User_List;

--Create Table for Isssued Books
CREATE TABLE Issued_Books(
book_issue_number int not null primary key identity(1,1),
issued_bookId int foreign key references Book_List(book_id),
issuedTo_userId int foreign key references User_List(user_id),
issue_date date
)
SELECT * FROM Issued_Books;

--Create Table For Fine Calculation
CREATE table Fine_Calculation(
id int not null PRIMARY KEY identity (1,1),
userId INT FOREIGN KEY REFERENCES User_List(user_id),
bookId INT foreign key REFERENCES Book_List(book_id),
issueDate DATE,
returnDate DATE,
fine INT 
)
SELECT * FROM Fine_Calculation;
 
--drop table Fine_Calculation
--drop table Issued_Books
--drop table User_List
--drop table Book_List
 